# 教师工作台在线版

Supabase 已接入。登录账号：Shaoyy，密码：258000。

## 上传前必须确认
在 Supabase → Authentication → Users 中，把教师用户的邮箱设置为：
`shaoyy@teacher.local`
并保持用户已确认（Confirmed）。

然后把 `index.html` 上传到 GitHub 仓库根目录。
